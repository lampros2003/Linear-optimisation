import numpy as np
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
from collections import deque

def create_initial_tableau():
    # Initial tableau with slack variables s1, s2, s3

    return np.array([
        [1, -2, -1, -6, 4, 0, 0, 0, 0],  
        [0, 1, 2, 4, -1, 1, 0, 0, 6],    
        [0, 2, 3, -1, 1, 0, 1, 0, 12],   
        [0, 1, 0, 1, 1, 0, 0, 1, 2]      
    ], dtype=float)
##pretty print our tableaux 
def display_tableau(tableau, basic_vars):
    columns = ['Z', 'x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃', 'RHS']
    df = pd.DataFrame(tableau, columns=columns)
    df.insert(0, 'Basic', basic_vars)
    return df

def find_entering_variables(tableau):
    # Find all <0 coefficients in objective row (potential entering vars)
    objective_coeffs = tableau[0, 1:-1]  # Skip Z column and RHS
    negative_indices = np.where(objective_coeffs < 0)[0]
    entering_candidates = [idx + 1 for idx in negative_indices]
    
    # Sort by absolute value (most negative first)
    return sorted(entering_candidates, key=lambda x: tableau[0, x])
    
def find_leaving_variables(tableau, entering_col):
    # Calculate ratios for minimum ratio test
    ratios = []
    for i in range(1, len(tableau)):
        if tableau[i, entering_col] <= 0:
            ratios.append((i, float('inf')))
        else:
            ratios.append((i, tableau[i, -1] / tableau[i, entering_col]))
    
    # Filter out infinity ratios
    valid_ratios = [r for r in ratios if r[1] != float('inf')]
    
    if not valid_ratios:
        return []  # No valid leaving variables (unbounded problem)
    
    # Find minimum ratio
    min_ratio = min(r[1] for r in valid_ratios)
    
    # Find all rows with minimum ratio (potential leaving variables)
    leaving_candidates = [row for row, ratio in ratios if ratio == min_ratio]
    
    return leaving_candidates

def pivot(tableau, basic_vars, entering_col, leaving_row):
   
    new_tableau = tableau.copy()
    new_basic_vars = basic_vars.copy()
    
    # Get the pivot element
    pivot_element = tableau[leaving_row, entering_col]
    
    #Update basic 
    col_names = ['Z', 'x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃']
    new_basic_vars[leaving_row-1] = col_names[entering_col]
    
    # Normalize pivot 
    new_tableau[leaving_row] = tableau[leaving_row] / pivot_element
    
    # Update  other rows
    for i in range(len(tableau)):
        if i != leaving_row:
            factor = tableau[i, entering_col]
            new_tableau[i] = tableau[i] - factor * new_tableau[leaving_row]
    
    return new_tableau, new_basic_vars

def is_optimal(tableau):
    # Check if all coefficients in objective row are non-negative
    objective_coeffs = tableau[0, 1:-1]  
    return np.all(objective_coeffs >= 0)

def solve_simplex():
    tableau = create_initial_tableau()
    basic_vars = ['Z', 's₁', 's₂', 's₃']
    
    print("Initial Tableau:")
    print(display_tableau(tableau, basic_vars))
    
    iteration = 0
    
    while not is_optimal(tableau):
        iteration += 1
        print(f"\nIteration {iteration}:")
        
        # Find potential entering variables
        entering_candidates = find_entering_variables(tableau)
        print(f"Potential entering variables: {[['Z', 'x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃'][col] for col in entering_candidates]}")
        
        # Select the entering variable (most negative coefficient)
        entering_col = entering_candidates[0]
        entering_var = ['Z', 'x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃'][entering_col]
        print(f"Selected entering variable: {entering_var}")
        
        #Find potential leaving vars
        leaving_candidates = find_leaving_variables(tableau, entering_col)
        
        if not leaving_candidates:
            print("Problem is unbounded!")
            return
        
        leaving_vars = [basic_vars[row-1] for row in leaving_candidates]
        print(f"Potential leaving variables: {leaving_vars}")
        
        # Select the leaving variable ,first candidate no special evaluation
        leaving_row = leaving_candidates[0]
        leaving_var = basic_vars[leaving_row-1]
        print(f"Selected leaving variable: {leaving_var}")
        
        # Perform pivot
        tableau, basic_vars = pivot(tableau, basic_vars, entering_col, leaving_row)
        print("New tableau:")
        print(display_tableau(tableau, basic_vars))
    
    # Extract solution
    print("\nOptimal solution found!")
    solution = {}
    for i, var in enumerate(basic_vars[1:]):  # Skip Z
        solution[var] = tableau[i+1, -1]
    
    # Set non-basic  to zero
    all_vars = ['x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃']
    for var in all_vars:
        if var not in basic_vars:
            solution[var] = 0
    
    print("\nSolution:")
    for var in ['x₁', 'x₂', 'x₃', 'x₄']:
        print(f"{var} = {solution.get(var, 0)}")
    
    print(f"\nObjective value: Z = {tableau[0, -1]}")

# Run 
solve_simplex()



def explore_all_paths():
    """
    Explores all possible paths in the simplex algorithm and creates
    an adjacency graph showing alternative routes to the optimal solution.
    """
    # Create a directed graph
    G = nx.DiGraph()
    
    # Start with the initial tableau and basic variables
    initial_tableau = create_initial_tableau()
    initial_basic_vars = ['Z', 's₁', 's₂', 's₃']
    
    # Use a tuple of basic variables (excluding Z) as node identifier
    initial_node = tuple(initial_basic_vars[1:])
    G.add_node(initial_node, tableau=initial_tableau, optimal=False, is_initial=True)
    
    # Use BFS to explore all paths
    queue = deque([(initial_tableau, initial_basic_vars, initial_node)])
    visited = {initial_node}
    
    while queue:
        tableau, basic_vars, current_node = queue.popleft()
        
        # Check if current tableau is optimal
        if is_optimal(tableau):
            G.nodes[current_node]['optimal'] = True
            G.nodes[current_node]['objective'] = tableau[0, -1]
            
            # Extract solution for this node
            solution = {}
            for i, var in enumerate(basic_vars[1:]):  # Skip Z
                solution[var] = tableau[i+1, -1]
            
            # Set non-basic variables to zero
            all_vars = ['x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃']
            for var in all_vars:
                if var not in basic_vars:
                    solution[var] = 0
                    
            G.nodes[current_node]['solution'] = solution
            continue
        
        # Find all potential entering variables
        entering_candidates = find_entering_variables(tableau)
        
        for entering_col in entering_candidates:
            # Find all potential leaving variables for this entering variable
            leaving_candidates = find_leaving_variables(tableau, entering_col)
            
            if not leaving_candidates:
                # Unbounded problem in this direction
                unbounded_node = "Unbounded"
                G.add_node(unbounded_node, is_unbounded=True)
                entering_var = ['Z', 'x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃'][entering_col]
                edge_label = f"Enter: {entering_var}"
                G.add_edge(current_node, unbounded_node, label=edge_label)
                continue
            
            for leaving_row in leaving_candidates:
                # Perform the pivot
                new_tableau, new_basic_vars = pivot(tableau, basic_vars, entering_col, leaving_row)
                
                # Create a new node identifier
                new_node = tuple(new_basic_vars[1:])  # Exclude Z
                
                # Add the new node and edge
                entering_var = ['Z', 'x₁', 'x₂', 'x₃', 'x₄', 's₁', 's₂', 's₃'][entering_col]
                leaving_var = basic_vars[leaving_row-1]
                edge_label = f"Enter: {entering_var}, Leave: {leaving_var}"
                
                if new_node not in visited:
                    G.add_node(new_node, tableau=new_tableau, optimal=is_optimal(new_tableau))
                    G.add_edge(current_node, new_node, label=edge_label)
                    
                    visited.add(new_node)
                    queue.append((new_tableau, new_basic_vars, new_node))
                else:
                    # Node already visited, just add the edge if it doesn't exist
                    if not G.has_edge(current_node, new_node):
                        G.add_edge(current_node, new_node, label=edge_label)
    
    # Visualize the graph
    plt.figure(figsize=(14, 12))
    
    # Position nodes using a layout algorithm
    pos = nx.spring_layout(G, seed=42)
    
    # Draw nodes with different colors
    initial_nodes = [node for node, data in G.nodes(data=True) if data.get('is_initial', False)]
    optimal_nodes = [node for node, data in G.nodes(data=True) if data.get('optimal', False)]
    non_optimal_nodes = [node for node in G.nodes() if node not in optimal_nodes 
                         and node not in initial_nodes and node != "Unbounded"]
    unbounded_nodes = [node for node in G.nodes() if node == "Unbounded"]
    
    nx.draw_networkx_nodes(G, pos, nodelist=initial_nodes, node_color='orange', 
                           node_size=800, label='Initial Basic Feasible Solution')
    nx.draw_networkx_nodes(G, pos, nodelist=non_optimal_nodes, node_color='lightblue', 
                           node_size=700, label='Intermediate BFS')
    nx.draw_networkx_nodes(G, pos, nodelist=optimal_nodes, node_color='lightgreen', 
                           node_size=800, label='Optimal Solution')
    if unbounded_nodes:
        nx.draw_networkx_nodes(G, pos, nodelist=unbounded_nodes, node_color='red', 
                               node_size=800, label='Unbounded')
    
    # Draw edges
    nx.draw_networkx_edges(G, pos, arrows=True, arrowsize=15)
    
    # Draw node labels
    node_labels = {}
    for node in G.nodes():
        if node == "Unbounded":
            node_labels[node] = "Unbounded"
        else:
            # Convert node tuple to readable format
            label = ", ".join(node)
            if G.nodes[node].get('optimal', False):
                label += f"\nZ={G.nodes[node]['objective']:.2f}"
                # Add solution values
                solution = G.nodes[node]['solution']
                for var in ['x₁', 'x₂', 'x₃', 'x₄']:
                    if var in solution and solution[var] > 0:
                        label += f"\n{var}={solution[var]:.2f}"
            node_labels[node] = label
    
    nx.draw_networkx_labels(G, pos, labels=node_labels, font_size=9)
    
    # Draw edge labels
    edge_labels = {(u, v): d['label'] for u, v, d in G.edges(data=True)}
    nx.draw_networkx_edge_labels(G, pos, edge_labels=edge_labels, font_size=8)
    
    plt.title("Simplex Adjacency Graph")
    plt.axis('off')
    plt.legend(loc='lower right')
    plt.tight_layout()
    plt.savefig("simplex_graph.png", dpi=300)
    plt.show()
    
    print("Graph visualization saved as 'simplex_graph.png'")
    
    # Print summary of paths
    print("\nSummary of all optimal solutions:")
    for node in optimal_nodes:
        solution = G.nodes[node]['solution']
        print(f"\nOptimal solution at basis {node} with Z = {G.nodes[node]['objective']:.2f}")
        
        for var in ['x₁', 'x₂', 'x₃', 'x₄']:
            print(f"  {var} = {solution.get(var, 0):.2f}")
    
    return G

# Run the simplex algorithm normally first
print("PART A: Standard Simplex Algorithm")
solve_simplex()

print("\n" + "="*50 + "\n")

# Now explore all paths
print("PART B: Exploring All Simplex Paths")
G = explore_all_paths()